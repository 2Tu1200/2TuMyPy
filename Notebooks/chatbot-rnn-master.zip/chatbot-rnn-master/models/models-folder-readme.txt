Place folders containing downloaded models in this directory.

You can download my own pre-trained model here: https://drive.google.com/uc?export=download&id=0B6noVJLTV1jCT29uMzliMVVRWWM